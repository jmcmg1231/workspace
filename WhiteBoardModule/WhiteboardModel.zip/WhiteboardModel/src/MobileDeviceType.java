public enum MobileDeviceType
{
    TABLET, EREADERS, WEARABLES, SMARTPHONES
}
